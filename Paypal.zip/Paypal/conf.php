<?php
include("../admin/database.php");


// PayPal settings
$paypal_email = "beaumarcelino@gmail.com";
$return_url = 'https://dev.single-solution.com/kids_clothing/Paypal/payment-successful.php';
$cancel_url = 'https://dev.single-solution.com/kids_clothing/index.php';
$notify_url = 'https://dev.single-solution.com/kids_clothing/Paypal/payments.php';

?>
